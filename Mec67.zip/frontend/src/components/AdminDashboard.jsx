
import { useEffect, useState } from "react";
import apiRequest from "../services/api";
import "./AdminDashboard.css";

function AdminDashboard({ onClose }) {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function loadContacts() {
    try {
      setLoading(true);
      setError("");

      const data = await apiRequest("/admin/contacts");
      setContacts(data.contacts || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function updateStatus(id, status) {
    try {
      await apiRequest(`/admin/contacts/${id}/status`, {
        method: "PATCH",
        body: JSON.stringify({ status }),
      });

      await loadContacts();
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    loadContacts();
  }, []);

  return (
    <div className="admin-overlay">
      <section className="admin-panel">
        <header className="admin-header">
          <div>
            <span> MEC67 / ADMINISTRACIÓN </span>
            <h2>Panel de administrador</h2>
          </div>

          <button onClick={onClose}>×</button>
        </header>

        <div className="admin-content">
          <h3>Mensajes de contacto</h3>

          {loading && <p>Cargando mensajes...</p>}

          {error && <p className="admin-error">{error}</p>}

          {!loading && !error && contacts.length === 0 && (
            <p>No hay mensajes registrados.</p>
          )}

          {contacts.map((contact) => (
            <article className="admin-contact" key={contact._id}>
              <div>
                <h4>{contact.name}</h4>
                <p>{contact.email}</p>
                <p>{contact.subject}</p>
                <p>{contact.message}</p>
                <small>
                  Estado: {contact.status || "new"}
                </small>
              </div>

              <select
                value={contact.status || "new"}
                onChange={(e) =>
                  updateStatus(contact._id, e.target.value)
                }
              >
                <option value="new">Nuevo</option>
                <option value="read">Leído</option>
                <option value="resolved">Resuelto</option>
              </select>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}

export default AdminDashboard;
