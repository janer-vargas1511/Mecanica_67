
import { Router } from "express";
import {
  authenticateToken,
  requireAdmin,
} from "../middleware/auth.js";
import Contact from "../models/Contact.js";

const router = Router();

// Todas las rutas de este archivo requieren autenticación
// y permisos de administrador.
router.use(authenticateToken, requireAdmin);

router.get("/dashboard", (req, res) => {
  res.json({
    success: true,
    message: "Bienvenido al panel administrativo de Mecánicas Six-Seven.",
    administrator: req.user.email,
    role: req.user.role,
  });
});


// Consultar mensajes recibidos
router.get("/contacts", async (req, res, next) => {
  try {
    const contacts = await Contact.find()
      .sort({ createdAt: -1 })
      .limit(100);

    res.json({
      success: true,
      total: contacts.length,
      contacts,
    });
  } catch (error) {
    next(error);
  }
});

// Actualizar el estado de un mensaje
router.patch(
  "/contacts/:id/status",
  async (req, res, next) => {
    try {
      const { status } = req.body;

      if (!["new", "read", "resolved"].includes(status)) {
        return res.status(400).json({
          success: false,
          message: "Estado de mensaje no válido.",
        });
      }

      const contact = await Contact.findByIdAndUpdate(
        req.params.id,
        { status },
        { new: true, runValidators: true }
      );

      if (!contact) {
        return res.status(404).json({
          success: false,
          message: "Mensaje no encontrado.",
        });
      }

      res.json({
        success: true,
        message: "Estado actualizado.",
        contact,
      });
    } catch (error) {
      next(error);
    }
  }
);


export default router;
